CREATE DATABASE library;
use library;
CREATE TABLE Users (
    user_id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20)
);


CREATE TABLE Books (
    book_id INT PRIMARY KEY,
    title VARCHAR(200),
    author VARCHAR(100)
);

CREATE TABLE Borrowing (
    borrow_id INT PRIMARY KEY,
    user_id INT,
    book_id INT,
    borrow_date DATE,
    return_date DATE,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (book_id) REFERENCES Books(book_id)
);



    SELECT 
    u.user_id AS 'User ID',
    u.name AS 'User Name',
    bk.book_id AS 'Book ID',
    bk.title AS 'Book Title',
    b.borrow_date AS 'Borrow Date',
    b.return_date AS 'Return Date'

    FROM 
    Borrowing b
JOIN 
    Users u ON b.user_id = u.user_id
JOIN 
    Books bk ON b.book_id = bk.book_id;



